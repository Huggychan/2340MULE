package ui.game;

import game.Mule;
import game.MuleGame;
import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import ui.Controller;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Created by southgatew on 9/18/15.
 */
public class WalkPaneController extends Controller<GameUI> {

    private class PlayerAnimation extends AnimationTimer {

        public final int MAX_MULE_SEPARATION = 50;

        public double velX;
        public double velY;
        private long lastTimestamp;

        @Override
        public void handle(long timestamp) {
            if(lastTimestamp > 0) {
                double dt = (timestamp - lastTimestamp) / 1000000000D;
                double dx = velX * dt;
                double dy = velY * dt;

                double newX = WalkPaneController.this.player.getTranslateX() + dx;
                double newY = WalkPaneController.this.player.getTranslateY() + dy;

                WalkPaneController.this.player.setTranslateX(newX);
                WalkPaneController.this.player.setTranslateY(newY);

                double muleX = WalkPaneController.this.mule.getTranslateX();
                double muleY = WalkPaneController.this.mule.getTranslateY();

                if (Math.abs(newX - muleX) > MAX_MULE_SEPARATION) {
                    if (newX - muleX > 0) {
                        muleX += newX - muleX - MAX_MULE_SEPARATION;
                    } else {
                        muleX += newX - muleX + MAX_MULE_SEPARATION;
                    }
                }
                if (Math.abs(newY - muleY) > MAX_MULE_SEPARATION) {
                    if (newY - muleY > 0) {
                        muleY += newY - muleY - MAX_MULE_SEPARATION;
                    } else {
                        muleY += newY - muleY + MAX_MULE_SEPARATION;
                    }
                }
                WalkPaneController.this.mule.setTranslateX(muleX);
                WalkPaneController.this.mule.setTranslateY(muleY);
            }

            lastTimestamp = timestamp;
        }

    }

    @FXML
    private Pane walkPane;
    @FXML
    private ImageView player;
    @FXML
    private ImageView mule;
    private Mule muleObject;
    private boolean isAssayMule = false;

    private PlayerAnimation playerAnimation;
    private static final int WALK_SPEED = 225;

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources) {
        playerAnimation = new PlayerAnimation();
        playerAnimation.start();

        walkPane.setMouseTransparent(true);
    }

    public void resetPlayerPosition() {
        player.setTranslateX(walkPane.getWidth() / 2 - (player.getImage().getWidth() / 2));
        player.setTranslateY(walkPane.getHeight() / 2 - (player.getImage().getHeight() / 2));
    }

    public double getPlayerX() {
        return player.getTranslateX() + (player.getImage().getWidth() / 2);
    }

    public double getPlayerY() {
        return player.getTranslateY() + (player.getImage().getHeight() / 2);
    }

    void onKeyPressed(KeyEvent event) {
        KeyCode code = event.getCode();

        if(code == KeyCode.UP) {
            playerAnimation.velY = -WALK_SPEED;
        } else if(code == KeyCode.DOWN) {
            playerAnimation.velY = WALK_SPEED;
        }

        if(code == KeyCode.RIGHT) {
            playerAnimation.velX = WALK_SPEED;
        } else if(code == KeyCode.LEFT) {
            playerAnimation.velX = -WALK_SPEED;
        }


    }

    void onKeyReleased(KeyEvent event) {
        if(getUi().getGameState() != MuleGame.GameState.Development)
        {
            return;
        }

        KeyCode code = event.getCode();

        if(code == KeyCode.UP || code == KeyCode.DOWN) {
            playerAnimation.velY = 0;
        }

        if(code == KeyCode.RIGHT || code == KeyCode.LEFT) {
            playerAnimation.velX = 0;
        }
    }

    void createAssayTool(Mule mule) {
        createMule(mule, true);
    }

    void createMule(Mule mule) {
        createMule(mule, false);
    }

    void createMule(Mule mule, boolean assay) {
        this.mule.setVisible(true);
        if (mule == null) {
            System.err.println("null mule given to the ui");
            return;
        }
        if (assay) {
            isAssayMule = true;
            this.mule.setImage(new Image("/images/assay-tool.png"));
        } else {
            isAssayMule = false;
            if (mule.getResource() == null) {
                //not outfitted yet
                this.mule.setImage(new Image("/images/ass.jpg"));
            } else {
                //has been outfitted
                this.mule.setImage(new Image("/images/outfit.png"));
            }
        }
        muleObject = mule;
        System.out.println("Mule Set");
    }

    Mule dropMule() {
        this.mule.setVisible(false);
        isAssayMule = false;
        return muleObject;
    }

    public Mule getMule() {
        return muleObject;
    }

    boolean hasMule() {
        return this.mule.isVisible();
    }

    boolean isAssay() { return isAssayMule && mule.isVisible(); }

}
