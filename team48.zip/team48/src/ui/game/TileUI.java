package ui.game;

import game.Mule;
import game.Resource;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by southgatew on 9/23/15.
 */
public class TileUI extends StackPane {

    private final static int BORDER_RADIUS = 3;
    private final static int TILE_WIDTH = 112;
    private final static int TILE_HEIGHT = 128;

    private final ImageView imageView;
    private final Map<Resource, ImageView> resourceImage;

    public TileUI() {
        int width = TILE_WIDTH - (BORDER_RADIUS * 2);
        int height = TILE_HEIGHT - (BORDER_RADIUS * 2);

        imageView = new ImageView();
        imageView.setPreserveRatio(true);
        imageView.setPickOnBounds(true);
        imageView.setFitWidth(width);
        imageView.setFitHeight(height);
        imageView.setViewport(new Rectangle2D(0, 0, width, height));
        getChildren().add(imageView);
        StackPane.setAlignment(imageView, Pos.CENTER);

        resourceImage = new HashMap<>();
        resourceImage.put(Resource.Energy, new ImageView(new Image(TileUI.class.getResourceAsStream("/images/tile/energy.png"))));
        resourceImage.put(Resource.Ore, new ImageView(new Image(TileUI.class.getResourceAsStream("/images/tile/ore.png"))));
        resourceImage.put(Resource.Food, new ImageView(new Image(TileUI.class.getResourceAsStream("/images/tile/food.png"))));

        for(ImageView iv : resourceImage.values()) {
            iv.setFitWidth(width / 3);
            iv.setFitHeight(height / 3);
            iv.setVisible(false);
            getChildren().add(iv);
            StackPane.setAlignment(iv, Pos.CENTER);
        }
    }

    public void setBorder(String color) {
        setStyle(String.format("-fx-border-color: %s;-fx-border-width: %d;", color, BORDER_RADIUS));
    }

    public void displayMule(Mule mule) {
        resourceImage.values().stream().forEach(iv -> iv.setVisible(false));

        if(mule != null) {
            resourceImage.get(mule.getResource()).setVisible(true);
        }
    }
    public ImageView getImageView() {
        return imageView;
    }

}
