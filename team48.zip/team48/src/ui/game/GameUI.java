package ui.game;

import game.MuleGame;
import game.Player;
import game.Resource;
import game.Tile;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created by southgatew on 9/18/15.
 */
public class GameUI implements MuleGame.MuleGameStateChangeListener {
    public enum GameUIState {
        MapView, TownView
    }

    private MuleGame game;

    private Stage stage;

    private final Map<Class<? extends Tile>, Image> tileTypeToImage;
    private MuleGame.GameState gameState;
    private GameUIState uiState;
    private final List<Consumer<GameUIState>> uiStateListeners;

    private Pane walkPane;
    private Pane mapPane;
    private Pane townPane;
    private Pane timerUIPane;
    private GameUIController gameUIController;
    private WalkPaneController walkPaneController;
    private MapPaneController mapPaneController;
    private TownPaneController townPaneController;
    private TimerUIController timerUiController;

    public GameUI() {
        tileTypeToImage = new HashMap<>();
        uiStateListeners = new LinkedList<>();

        addUIStateListener(uiState -> {
            switch (uiState) {
                case MapView:
                    mapPane.setVisible(true);
                    townPane.setVisible(false);
                    break;
                case TownView:
                    mapPane.setVisible(false);
                    townPane.setVisible(true);
            }
        });
    }

    public void open(MuleGame game) {
        this.game = game;

        game.addGameStateListener(this);

        try {
            tileTypeToImage.put(Tile.Town.class, new Image(GameUI.class.getResourceAsStream("/images/tile/town.png")));
            tileTypeToImage.put(Tile.River.class, new Image(GameUI.class.getResourceAsStream("/images/tile/river.png")));
            tileTypeToImage.put(Tile.Plain.class, new Image(GameUI.class.getResourceAsStream("/images/tile/plain.png")));
            tileTypeToImage.put(Tile.Mountain1.class, new Image(GameUI.class.getResourceAsStream("/images/tile/mountain1.png")));
            tileTypeToImage.put(Tile.Mountain2.class, new Image(GameUI.class.getResourceAsStream("/images/tile/mountain2.png")));
            tileTypeToImage.put(Tile.Mountain3.class, new Image(GameUI.class.getResourceAsStream("/images/tile/mountain3.png")));

            stage = new Stage();
            stage.setResizable(false);
            stage.setWidth(1064);
            stage.setHeight(740);

            FXMLLoader gameUILoader = new FXMLLoader(GameUI.class.getResource("GameUI.fxml"));
            GridPane gameUIPane = gameUILoader.load();
            gameUIController = gameUILoader.<GameUIController>getController();
            gameUIController.setUiAndGame(game, this);
            FXMLLoader timerLoader = new FXMLLoader(GameUI.class.getResource("Timer.fxml"));
            timerUIPane = timerLoader.load();
            timerUiController = timerLoader.<TimerUIController>getController();
            timerUiController.setUiAndGame(game, this);
            gameUIController.getGamePane().getChildren().add(timerUIPane);
            timerUIPane.setVisible(false);

            FXMLLoader mapPaneLoader = new FXMLLoader(GameUI.class.getResource("MapPaneUI.fxml"));
            mapPane = mapPaneLoader.load();
            mapPaneController = mapPaneLoader.<MapPaneController>getController();
            mapPaneController.setUiAndGame(game, this);
            gameUIController.getGamePane().getChildren().add(mapPane);


            for (int r = 0; r < MuleGame.ROWS; r++) {
                for (int c = 0; c < MuleGame.COLUMNS; c++) {
                    Tile tile = game.getMap()[r][c];
                    if (tile != null) {
                        Image img = tileTypeToImage.get(tile.getClass());
                        mapPaneController.getTiles()[r][c].getImageView().setImage(img);
                    }
                }
            }

            FXMLLoader townPaneLoader = new FXMLLoader(GameUI.class.getResource("TownPaneUI.fxml"));
            townPane = townPaneLoader.load();
            townPaneController = townPaneLoader.<TownPaneController>getController();
            townPaneController.setUiAndGame(game, this);
            gameUIController.getGamePane().getChildren().add(townPane);

            FXMLLoader walkPaneLoader = new FXMLLoader(GameUI.class.getResource("WalkPaneUI.fxml"));
            walkPane = walkPaneLoader.load();
            walkPaneController = walkPaneLoader.<WalkPaneController>getController();
            walkPaneController.setUiAndGame(game, this);
            gameUIController.getGamePane().getChildren().add(walkPane);

            Scene scene = new Scene(gameUIPane);
            scene.addEventHandler(KeyEvent.KEY_PRESSED, this::onKeyPressed);
            scene.addEventHandler(KeyEvent.KEY_RELEASED, this::onKeyReleased);
            stage.setScene(scene);
            stage.setTitle("MULE");
            stage.show();

            stateUpdated(game.getCurrentState());
        } catch (Exception ex) {
            Logger.getLogger(GameUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void close() {
        stage.close();
    }


    public void stateUpdated(MuleGame.GameState state) {
        this.gameState = state;

        this.walkPaneController.dropMule();

        switch (state) {
            case LandBuy:
                uiStateUpdated(GameUIState.MapView);
                walkPane.setVisible(false);

                Player player = game.getCurrentPlayer();
                gameUIController.setBottomMessage(String.format("%s select a property ($%d)", player.getName(), player.getMoney()));
                gameUIController.showPass();

                break;
            case Development:
                gameUIController.hidePass();
                TranslateTransition transition = gameUIController.showEventMessage(game.eventMessage);
                if(transition != null) {
                    transition.setOnFinished(e -> gameUIController.hideEventMessage());
                    transition.playFromStart();
                }

                uiStateUpdated(GameUIState.MapView);
                walkPane.setVisible(true);

                updateGameBottomMessage(game.getCurrentPlayer());
                walkPaneController.resetPlayerPosition();

                game.saveToFile("mulegame.txt");

                break;
        }
    }

    public void roundTimerChanged(boolean isRunning, int remaining, boolean isTimerSet) {
        if(isTimerSet) {
            timerUiController.setInitTime(remaining);
        }

        if (isRunning) {
            timerUIPane.setVisible(true);
            timerUiController.setTime(remaining);
        } else {
            timerUIPane.setVisible(false);
        }
    }

    public void uiStateUpdated(GameUIState uiState) {
        if (uiState == GameUIState.MapView && this.uiState == GameUIState.TownView) {
            walkPaneController.resetPlayerPosition();
        }

        this.uiState = uiState;
        uiStateListeners.forEach(ui -> ui.accept(uiState));
    }

    private void addUIStateListener(Consumer<GameUIState> listener) {
        uiStateListeners.add(listener);
    }

    public MuleGame.GameState getGameState() {
        return gameState;
    }

    public GameUIController getGameUIController() {return gameUIController; }

    public WalkPaneController getWalkPaneController() {
        return walkPaneController;
    }

    public void updateGameBottomMessage(Player player) {
        gameUIController.setBottomMessage(String.format(
                "%s's turn | Money: %d | Food: %d | Energy: %d | Ore: %d",
                player.getName(), player.getMoney(), player.getInventory().getItem(Resource.Food),
                player.getInventory().getItem(Resource.Energy), player.getInventory().getItem(Resource.Ore)
        ));
    }

    private void onKeyPressed(KeyEvent event) {
        // Dispatch the key event to the appropriate children
        if (gameState == MuleGame.GameState.Development) {
            walkPaneController.onKeyPressed(event);

            // Allow yielding your turn
            if (event.getCode() == KeyCode.SPACE) {
                game.stepState();
            }
        }

        switch (uiState) {
            case MapView:
                mapPaneController.onKeyPressed(event);
                break;
            case TownView:
                townPaneController.onKeyPressed(event);
                break;
        }
    }

    private void onKeyReleased(KeyEvent event) {
        // Dispatch the key event to the appropriate children
        if (gameState == MuleGame.GameState.Development) {
            walkPaneController.onKeyReleased(event);
        }

        switch (uiState) {
            case MapView:
                //mapPaneController.onKeyReleased(event);
                break;
            case TownView:
                //townPaneController.onKeyReleased(event);
                break;
        }
        //mapPaneController.onKeyPressed(event);
    }

    public void forceUIUpdate() {
        mapPaneController.forceUIUpdate();
        timerUiController.forceUIUpdate();
    }
}
