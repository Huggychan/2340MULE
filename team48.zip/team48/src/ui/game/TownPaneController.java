package ui.game;

import game.*;
import javafx.fxml.FXML;
import javafx.geometry.Point2D;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import ui.Controller;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * Created by southgatew on 9/18/15.
 */
public class TownPaneController extends Controller<GameUI> {

    @FXML
    private Pane townPane;
    @FXML
    private ImageView landOffice;
    @FXML
    private ImageView mule;
    @FXML
    private ImageView pub;
    @FXML
    private ImageView assay;
    @FXML
    private Label buyOre;
    @FXML
    private Label buyFood;
    @FXML
    private Label buyEnergy;
    @FXML
    private Label buyCrystite;
    @FXML
    private Label sellOre;
    @FXML
    private Label sellFood;
    @FXML
    private Label sellEnergy;
    @FXML
    private Label sellCrystite;
    @FXML
    private Label muleOre;
    @FXML
    private Label muleFood;
    @FXML
    private Label muleEnergy;
    @FXML
    private Label muleCrystite;
    @FXML
    private GridPane storeGrid;

    private Map<Label, Resource> buyLabels;
    private Map<Label, Resource> sellLabels;

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources) {
        buyLabels = new HashMap<>();
        buyLabels.put(buyOre, Resource.Ore);
        buyLabels.put(buyFood, Resource.Food);
        buyLabels.put(buyEnergy, Resource.Energy);
        buyLabels.put(buyCrystite, Resource.Crystite);

        sellLabels = new HashMap<>();
        sellLabels.put(sellOre, Resource.Ore);
        sellLabels.put(sellFood, Resource.Food);
        sellLabels.put(sellEnergy, Resource.Energy);
        sellLabels.put(sellCrystite, Resource.Crystite);
    }

    @Override
    public void setUiAndGame(MuleGame game, GameUI ui) {
        super.setUiAndGame(game, ui);

        updateStoreLabel();
    }

    protected void onKeyPressed(KeyEvent event) {
        KeyCode code = event.getCode();

        if (code == KeyCode.ENTER) { // Enter pressed
            WalkPaneController walkPaneController = getUi().getWalkPaneController();
            Player currentPlayer = game.getCurrentPlayer();
            Store store = game.getStore();

            int x = (int) walkPaneController.getPlayerX();
            int y = (int) walkPaneController.getPlayerY();
            Point2D storePlayer = storeGrid.parentToLocal(x, y);

            if (assay.contains(assay.parentToLocal(x, y))) {
                System.out.println("Player entered assay office");
                walkPaneController.createMule(new Mule.NonOutfittedMule(),
                        true);
            } else if (pub.contains(pub.parentToLocal(x, y))) {
                System.out.println("Player entered pub");
                game.gamble();
                return;
            } else if (mule.contains(mule.parentToLocal(x, y))) {
                System.out.println("Player entered mule shop");

                if (store.purchaseResource(Resource.Mule, currentPlayer)) {
                    walkPaneController.createMule(new Mule.NonOutfittedMule());
                }
            } else if (landOffice.contains(landOffice.parentToLocal(x, y))) {
                System.out.println("Player entered land office");
            } else if (storeGrid.contains(storePlayer)) {
                System.out.println("Player is in the store");
                buyLabels.forEach((l, r) -> {
                    if (l.contains(l.parentToLocal(storePlayer))) {
                        store.purchaseResource(r, currentPlayer);
                    }
                });
                sellLabels.forEach((l, r) -> {
                    if (l.contains(l.parentToLocal(storePlayer))) {
                        store.sellResource(r, currentPlayer);
                    }
                });

                if (walkPaneController.getMule() != null && walkPaneController.getMule().getResource() == null) {
                    Mule mule = null;
                    if (muleOre.contains(muleOre.parentToLocal(storePlayer))) {
                        mule = new Mule.OreMule();
                    } else if (muleFood.contains(muleFood.parentToLocal(storePlayer))) {
                        mule = new Mule.FoodMule();
                    } else if (muleEnergy.contains(muleEnergy.parentToLocal(storePlayer))) {
                        mule = new Mule.EnergyMule();
                    } else if (muleCrystite.contains(muleCrystite.parentToLocal(storePlayer))) {
                        mule = new Mule.CrystiteMule();
                    }

                    if (mule != null) {
                        if (store.purchaseOutfitMule(mule, currentPlayer)) {
                            walkPaneController.createMule(mule);
                        }
                    }
                }

                updateStoreLabel();
            }

            getUi().updateGameBottomMessage(currentPlayer);
        } else if (event.getCode() == KeyCode.ESCAPE) {
            getUi().uiStateUpdated(GameUI.GameUIState.MapView);
        }
    }

    public void updateStoreLabel() {
        Store store = game.getStore();
        buyLabels.forEach((l, r) -> l.setText(
                String.format("$%d (%d)", r.getBasePrice(), store.getInventory().getItem(r))));
    }

}
