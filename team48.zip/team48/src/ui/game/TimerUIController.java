package ui.game;

import javafx.fxml.FXML;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import ui.Controller;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Created by southgatew on 9/18/15.
 */
public class TimerUIController extends Controller<GameUI> {
    private static final float MAX_WIDTH = 200;
    private float initTime;

    @FXML
    private Rectangle timer_bar;
    @FXML
    private Text timerText;

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources) {


    }
    public void forceUIUpdate() {
        initTime = 40;
    }

    public void setInitTime(float initTime) {
        this.initTime = initTime;
    }

    public void setTime(float timeRemaining) {
        timer_bar.setWidth(calcWidth(timeRemaining));
        timerText.setText("Time Remaining: " + (int)timeRemaining);
    }

    private int calcWidth(float timeRemaining) {
        return (int) ((timeRemaining / initTime) * MAX_WIDTH);
    }



}