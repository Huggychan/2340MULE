package ui.game;

import game.Mule;
import game.MuleGame;
import game.Player;
import game.Tile;
import javafx.fxml.FXML;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import ui.Controller;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Created by southgatew on 9/18/15.
 */
public class MapPaneController extends Controller<GameUI> {

    private static String STYLE_PADDING = "-fx-padding: 6px";
    @FXML
    private GridPane mapPane;

    private TileUI[][] tiles;

    private Tile[][] map;

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources) {

    }

    @Override
    public void setUiAndGame(MuleGame game, GameUI ui) {
        super.setUiAndGame(game, ui);

        tiles = new TileUI[MuleGame.ROWS][MuleGame.COLUMNS];

        for (int r = 0; r < MuleGame.ROWS; r++) {
            for (int c = 0; c < MuleGame.COLUMNS; c++) {
                TileUI tileUI = new TileUI();
                final int fr = r;
                final int fc = c;
                tileUI.getImageView().addEventFilter(MouseEvent.MOUSE_CLICKED, e -> purchaseTile(fr, fc));

                mapPane.add(tileUI, c, r);
                tiles[r][c] = tileUI;
            }
        }
        map = game.getMap();
    }

    public TileUI[][] getTiles() {
        return tiles;
    }

    private static int getTileCol(int x) {
        return x / 112;
    }

    private static int getTileRow(int y) {
        return y / 128;
    }

    public void onKeyPressed(KeyEvent event) {
        WalkPaneController walkPaneController = getUi().getWalkPaneController();
        int x = (int) walkPaneController.getPlayerX();
        int y = (int) walkPaneController.getPlayerY();

        MuleGame.GameState state = getUi().getGameState();

        if (state == MuleGame.GameState.Development) {
            if (event.getCode() == KeyCode.ENTER) {
                Tile currentTile = map[getTileRow(y)][getTileCol(x)];

                if (getUi().getWalkPaneController().isAssay()) {
                    getUi().getWalkPaneController().dropMule();
                    String crystiteMsg = "";
                    switch(currentTile.getCrystiteLevel()) {
                        case 1:
                            crystiteMsg += "Low";
                            break;
                        case 2:
                            crystiteMsg += "Medium";
                            break;
                        case 3:
                            crystiteMsg += "High";
                            break;
                        case 4:
                            crystiteMsg += "Very high";
                            break;
                        default:
                            crystiteMsg += "No";
                            break;
                    }
                    crystiteMsg += " levels of crystite on tile " +
                            (getTileCol(y) + 1) + ", " + (getTileCol(x) + 1);
                    System.out.println(crystiteMsg);
                    getUi().getGameUIController().showEventMessage(crystiteMsg);
                } else if (currentTile instanceof Tile.Town) {
                    getUi().uiStateUpdated(GameUI.GameUIState.TownView);
                } else if (getUi().getWalkPaneController().hasMule()) {
                    if (currentTile.getOwner() != null && currentTile.getOwner().equals(game.getCurrentPlayer())
                            && currentTile.getMule() == null) {
                        Mule mule = getUi().getWalkPaneController().dropMule();
                        //place outfitted tile
                        tiles[getTileRow(y)][getTileCol(x)].displayMule(mule);
                        map[getTileRow(y)][getTileCol(x)].placeMule(mule);
                    } else {
                        getUi().getWalkPaneController().dropMule();
                    }
                } else if (currentTile.getOwner() != null && currentTile.getOwner().equals(game.getCurrentPlayer())) {
                    if (currentTile.getMule() != null) {
                        walkPaneController.createMule(currentTile.removeMule());
                        tiles[getTileRow(y)][getTileCol(x)].displayMule(null);
                    }
                }
            }
        }
    }

    private void purchaseTile(int row, int col) {
        if (getUi().getGameState() == MuleGame.GameState.LandBuy) {
            Player player = game.getCurrentPlayer();

            if (!(col == 4 && row == 2) && player.purchaseTile(game.getMap()[row][col])) {
                tiles[row][col].setBorder(player.getColor().toString().toLowerCase());
                game.stepState();
            }
        }
    }

    public void forceUIUpdate() {
        for (int r = 0; r < tiles.length; r++) {
            for (int c = 0; c < tiles[0].length; c++) {
                Tile t = game.getMap()[r][c];
                if (t.getOwner() != null) {
                    tiles[r][c].setBorder(t.getOwner().getColor().toString().toLowerCase());
                }

                tiles[r][c].displayMule(t.getMule());

            }
        }
    }
}