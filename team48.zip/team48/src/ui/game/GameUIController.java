package ui.game;

import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.animation.TranslateTransitionBuilder;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;
import ui.Controller;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Created by southgatew on 9/18/15.
 */
public class GameUIController extends Controller<GameUI> {

    @FXML
    private GridPane mainPane;
    @FXML
    private StackPane gamePane;
    @FXML
    private Label name;
    @FXML
    private Button pass;
    @FXML
    private Label event;

    private int numPass;

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources) {
        pass.setOnAction(e -> {
            if (++numPass == game.getPlayers().size()) {
                game.disableLandBuy();
            }
            game.stepState();
        });
    }

    public void hidePass() {
        pass.setVisible(false);
        numPass = 0;
    }

    public void showPass() {
        pass.setVisible(true);
    }

    public StackPane getGamePane() {
        return gamePane;
    }

    public void setBottomMessage(String newMessage) {
        this.name.setText(newMessage);
    }

    public void setEventMessage(String eventMsg) {
        event.setVisible(true);
        event.setText(eventMsg);
    }

    public TranslateTransition showEventMessage(String eventMsg) {
        if(eventMsg != null) {
            event.setVisible(true);
            event.setText(eventMsg);
            TranslateTransition transition = TranslateTransitionBuilder.create()
                    .duration(new Duration(10))
                    .node(event)
                    .interpolator(Interpolator.LINEAR)
                    .cycleCount(1)
                    .build();
            transition.setToX(event.getBoundsInLocal().getMaxX() * -1 - 100);
            transition.setFromX(gamePane.widthProperty().get() + 100);

            double distance = gamePane.widthProperty().get() + 2 * event.getBoundsInLocal().getMaxX();
            transition.setDuration(new Duration(distance / 0.15));

            return transition;
        }

        return null;
    }

    public void hideEventMessage() {
        event.setVisible(false);
    }

}


