package ui;

import game.MuleGame;
import javafx.fxml.Initializable;

/**
 * Created by southgatew on 9/18/15.
 */
public abstract class Controller<T> implements Initializable {

    private T ui;
    protected MuleGame game;

    public T getUi() {
        return ui;
    }

    public void setUiAndGame(MuleGame game, T ui) {
        this.ui = ui;
        this.game = game;
    }
}
