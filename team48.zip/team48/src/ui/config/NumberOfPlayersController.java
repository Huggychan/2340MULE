package ui.config;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import ui.Controller;

import java.net.URL;
import java.util.ResourceBundle;

public class NumberOfPlayersController extends Controller<NumberOfPlayersUI> {

    @FXML
    private Button two_players_button;

    @FXML
    private Button three_players_button;

    @FXML
    private Button four_players_button;

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources) {
        assert two_players_button != null : "fx:id=\"two_players_button\" was not injected: check your FXML file 'NumberOfPlayersUI.fxml'.";
        assert three_players_button != null : "fx:id=\"three_players_button\" was not injected: check your FXML file 'NumberOfPlayersUI.fxml'.";
        assert four_players_button != null : "fx:id=\"four_players_button\" was not injected: check your FXML file 'NumberOfPlayersUI.fxml'.";

        two_players_button.setOnAction((event) -> nextScreen(2));

        three_players_button.setOnAction((event) -> nextScreen(3));

        four_players_button.setOnAction((event) -> nextScreen(4));

    }

    private void nextScreen(int players) {
        getUi().close();
        new PlayerSetupUI(players).open(game);
    }

}
