package ui.config;

import java.util.logging.Level;
import java.util.logging.Logger;

import game.MuleGame;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class DifficultySelectUI {

    private Stage stage;

    public void open(MuleGame game) {
        try {
            stage = new Stage();
            FXMLLoader loader = new FXMLLoader(DifficultySelectUI.class.getResource("DifficultySelectUI.fxml"));
            stage.setScene(new Scene(loader.load()));
            loader.<DifficultySelectController>getController().setUiAndGame(game, this);
            stage.setTitle("Select Game Difficulty");
            stage.show();
        } catch (Exception ex) {
            Logger.getLogger(DifficultySelectUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void close() {
        stage.close();
    }


}

