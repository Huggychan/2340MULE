package ui.config;

import game.MuleGame;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import ui.Controller;
import ui.game.GameUI;

import java.net.URL;
import java.util.ResourceBundle;

public class MapSelectController extends Controller<MapSelectUI> {

    @FXML
    private Button standard_map_button;

    @FXML
    private Button mountainous_map_button;

    @FXML
    private Button flat_map_button;

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources) {
        assert standard_map_button != null : "fx:id=\"standard_map_button\" was not injected: check your FXML file 'NumberOfPlayersUI.fxml'.";
        assert mountainous_map_button != null : "fx:id=\"mountainous_map_button\" was not injected: check your FXML file 'NumberOfPlayersUI.fxml'.";
        assert flat_map_button != null : "fx:id=\"flat_map_button\" was not injected: check your FXML file 'NumberOfPlayersUI.fxml'.";

        standard_map_button.setOnAction((event) -> nextScreen(MuleGame.MapType.Standard));

        mountainous_map_button.setOnAction((event) -> nextScreen(MuleGame.MapType.Mountainous));

        flat_map_button.setOnAction((event) -> nextScreen(MuleGame.MapType.Flat));

    }

    private void nextScreen(MuleGame.MapType map) {
        game.generateMap(map);
        getUi().close();
        new GameUI().open(game);
    }

}
