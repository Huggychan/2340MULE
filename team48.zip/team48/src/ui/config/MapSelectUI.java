package ui.config;

import java.util.logging.Level;
import java.util.logging.Logger;

import game.MuleGame;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MapSelectUI {

    private Stage stage;

    public void open(MuleGame game) {
        try {
            stage = new Stage();
            FXMLLoader loader = new FXMLLoader(MapSelectUI.class.getResource("MapSelectUI.fxml"));
            stage.setScene(new Scene(loader.load()));
            loader.<MapSelectController>getController().setUiAndGame(game, this);
            stage.setTitle("Pick Game MapType");
            stage.show();
        } catch (Exception ex) {
            Logger.getLogger(MapSelectUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void close() {
        stage.close();
    }


}

