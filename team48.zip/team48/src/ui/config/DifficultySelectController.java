package ui.config;

import java.net.URL;
import java.util.ResourceBundle;

import game.MuleGame;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import ui.Controller;

public class DifficultySelectController extends Controller<DifficultySelectUI> {

    @FXML
    private Button beginner_button;

    @FXML
    private Button standard_button;

    @FXML
    private Button tournament_button;

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources) {
        assert beginner_button != null : "fx:id=\"beginner_button\" was not injected: check your FXML file 'DifficultySelectUI.fxml'.";
        assert standard_button != null : "fx:id=\"standard_button\" was not injected: check your FXML file 'DifficultySelectUI.fxml'.";
        assert tournament_button != null : "fx:id=\"tournament_button\" was not injected: check your FXML file 'DifficultySelectUI.fxml'.";

        beginner_button.setOnAction((event) -> nextScreen(MuleGame.Difficulty.Beginner));

        standard_button.setOnAction((event) -> nextScreen(MuleGame.Difficulty.Standard));

        tournament_button.setOnAction((event) -> nextScreen(MuleGame.Difficulty.Tournament));

    }

    private void nextScreen(MuleGame.Difficulty difficulty)
    {
        game.setDifficulty(difficulty);
        getUi().close();
        new MapSelectUI().open(game);
    }

}
