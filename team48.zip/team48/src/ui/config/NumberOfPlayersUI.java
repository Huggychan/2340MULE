package ui.config;

import java.util.logging.Level;
import java.util.logging.Logger;

import game.MuleGame;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class NumberOfPlayersUI {

    private Stage stage;

    public void open(MuleGame game) {
        try {
            stage = new Stage();
            FXMLLoader loader = new FXMLLoader(NumberOfPlayersUI.class.getResource("NumberOfPlayersUI.fxml"));
            stage.setScene(new Scene(loader.load()));
            loader.<NumberOfPlayersController>getController().setUiAndGame(game, this);
            stage.setTitle("Pick the Number of Players");
            stage.show();
        } catch (Exception ex) {
            Logger.getLogger(NumberOfPlayersUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void close() {
        stage.close();
    }

}

