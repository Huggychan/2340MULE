package ui.config;

import game.MuleGame;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created by Matthew on 9/11/2015.
 */
public class PlayerSetupUI {

    private int numPlayers;
    private int curPlayer;

    public PlayerSetupUI(int numPlayers) {
        this.numPlayers = numPlayers;
        curPlayer = 1;
    }

    private Stage stage;

    public void open(MuleGame game) {
        try {
            stage = new Stage();
            FXMLLoader loader = new FXMLLoader(PlayerSetupUI.class.getResource("PlayerSetupUI.fxml"));
            stage.setScene(new Scene(loader.load()));
            loader.<PlayerSetupController>getController().setUiAndGame(game, this);
            stage.setTitle("Setup Player 1");
            stage.show();
        } catch (Exception ex) {
            Logger.getLogger(PlayerSetupUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void close() {
        stage.close();
    }

    public boolean addPlayer() {
        if(--numPlayers > 0) {
            curPlayer++;
            stage.setTitle(String.format("Setup Player %d", curPlayer));
            return true;
        }

        return false;
    }
}
