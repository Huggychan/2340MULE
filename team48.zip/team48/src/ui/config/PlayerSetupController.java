package ui.config;

import game.Player;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import ui.Controller;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Created by Matthew on 9/11/2015.
 */
public class PlayerSetupController extends Controller<PlayerSetupUI> {
    @FXML
    private TextField playerName;

    @FXML
    private ComboBox playerRace;

    @FXML
    private ComboBox playerColor;

    @FXML
    private Button continueButton;

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources) {
        // Inflate the color picker
        for (Player.Color c : Player.Color.values()) {
            playerColor.getItems().add(c);
        }

        // Inflate the race picker
        for (Player.Race r : Player.Race.values()) {
            playerRace.getItems().add(r);
        }

        // Enter presses the button (as default)
        continueButton.setDefaultButton(true);

        // Handle the continue button being pressed
        continueButton.setOnAction((event) -> {
            String name = playerName.getText();
            if (!Player.validateName(name)) {
                return;
            }

            Object oRace = playerRace.getValue();
            if (oRace == null || !(oRace instanceof Player.Race)) {
                return;
            }
            Player.Race race = (Player.Race) oRace;

            Object oColor = playerColor.getValue();
            if (oColor == null || !(oColor instanceof Player.Color)) {
                return;
            }
            Player.Color color = (Player.Color) oColor;

            playerColor.getItems().remove(oColor);

            game.addPlayer(new Player(name, race, color));

            if (getUi().addPlayer()) {
                playerName.setText("");
                playerRace.setValue(null);
                playerColor.setValue(null);

            } else {
                getUi().close();
                new DifficultySelectUI().open(game);
            }
        });
    }

}
