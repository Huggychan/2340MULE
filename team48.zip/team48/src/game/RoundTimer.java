package game;

import javafx.application.Platform;

import java.io.Serializable;

/**
 * Created by matth on 9/30/2015.
 */
public class RoundTimer implements Serializable {
    private transient Thread thr;

    private int remaining;
    private boolean isRunning;

    public synchronized int getRemaining() {
        return this.remaining;
    }

    public RoundTimer() {

    }

    synchronized void cancelTimer() {
        isRunning = false;
        // Make sure that it dies right away
        if (thr != null) {
            thr.interrupt();
        }
    }

    synchronized void setTimer(final int seconds) {
        cancelTimer();

        thr = new Thread(() -> {
            remaining = seconds;

            while (isRunning) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException exc) {
                    return;
                }

                if (!isRunning) {
                    return;
                }

                remaining--;

                if (remaining == 0) {
                    isRunning = false;

                    onTimerExpiry();
                } else {
                    onTimerTick(remaining);
                }
            }
        });

        isRunning = true;

        thr.setDaemon(true); // make game close even if this thread is running
        thr.start();
    }

    private void onTimerTick(int remaining) {
        Platform.runLater(() -> {
            synchronized (callbackSync) {
                if (this.callback != null) {
                    this.callback.onTimerTick(remaining);
                }
            }
        });
    }

    private void onTimerExpiry() {
        Platform.runLater(() -> {
            synchronized (callbackSync) {
                if(this.callback != null) {
                    this.callback.onTimerExpiry();
                }
            }
        });
    }

    public interface RoundTimerCallback {
        void onTimerTick(int remaining);

        void onTimerExpiry();
    }

    public void fixAfterDeserialize() {
        callbackSync = new Object();
    }

    private transient Object callbackSync = new Object();
    private RoundTimerCallback callback;

    public synchronized void setCallback(RoundTimerCallback newCallback) {
        synchronized (callbackSync) {
            this.callback = newCallback;
        }
    }
}
