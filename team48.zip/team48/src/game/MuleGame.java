package game;

import java.io.*;
import java.util.*;

/**
 * Main game runner
 *
 * @author Yash The Enforcer (Team 48)
 */
public class MuleGame implements RoundTimer.RoundTimerCallback, Serializable {

    private static final Item[] STANDARD_TOURNAMENT_PLAYER = new Item[]{
            new Item(Resource.Food, 4),
            new Item(Resource.Ore, 0),
            new Item(Resource.Energy, 2),
            new Item(Resource.Crystite, 0)
    };

    private static final Item[] STANDARD_TOURNAMENT_STORE = new Item[]{
            new Item(Resource.Food, 8),
            new Item(Resource.Ore, 8),
            new Item(Resource.Energy, 8),
            new Item(Resource.Crystite, 0),
            new Item(Resource.Mule, 14)
    };

    public enum Difficulty {

        Beginner(
                new Item[]{
                        new Item(Resource.Food, 8),
                        new Item(Resource.Ore, 0),
                        new Item(Resource.Energy, 4),
                        new Item(Resource.Crystite, 0)
                },
                new Item[]{
                        new Item(Resource.Food, 16),
                        new Item(Resource.Ore, 0),
                        new Item(Resource.Energy, 16),
                        new Item(Resource.Crystite, 0),
                        new Item(Resource.Mule, 25)
                }
        ),

        Standard(MuleGame.STANDARD_TOURNAMENT_PLAYER, MuleGame.STANDARD_TOURNAMENT_STORE),
        Tournament(MuleGame.STANDARD_TOURNAMENT_PLAYER, MuleGame.STANDARD_TOURNAMENT_STORE);

        private final Item[] startingPlayer;
        private final Item[] startingStore;

        Difficulty(Item[] startingPlayer, Item[] startingStore) {
            this.startingPlayer = startingPlayer;
            this.startingStore = startingStore;
        }

        public Item[] getStartingPlayer() {
            return startingPlayer;
        }

        public Item[] getStartingStore() {
            return startingStore;
        }
    }

    public enum MapType {Standard, Mountainous, Flat, Random}

    public static final int COLUMNS = 9;
    public static final int ROWS = 5;

    private final List<Player> players;
    private final Tile[][] map;
    private final List<RandomEvent> randomEvents;
    private int turn;
    private Difficulty difficulty;

    private final RoundTimer timer;
    private final Store store;
    private Player currentPlayer;

    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    public List<Player> getPlayers() {
        return players;
    }

    public MuleGame() {
        players = new ArrayList<>();
        map = new Tile[ROWS][COLUMNS];
        timer = new RoundTimer();
        timer.setCallback(this);
        turn = 0;
        store = new Store();

        randomEvents = new ArrayList<>();
        randomEvents.add(new RandomEvent.RandomEvent1());
        randomEvents.add(new RandomEvent.RandomEvent2());
        randomEvents.add(new RandomEvent.RandomEvent3());
        randomEvents.add(new RandomEvent.RandomEvent4());
        randomEvents.add(new RandomEvent.RandomEvent5());
        randomEvents.add(new RandomEvent.RandomEvent6());
        randomEvents.add(new RandomEvent.RandomEvent7());
    }

    public void addPlayer(Player p) {
        players.add(p);
    }

    private void initGame() {
        for (Item item : difficulty.getStartingStore()) {
            store.getInventory().addItem(item);
        }

        for (Player player : players) {
            for (Item item : difficulty.getStartingPlayer()) {
                player.getInventory().addItem(item);
            }
        }
    }

    public void setDifficulty(Difficulty difficulty) {
        this.difficulty = difficulty;
    }

    public void generateMap(MapType mapType) {
        //generates centre row (town and river)

        for (int i = 0; i < ROWS; i++) {
            if (i == ROWS / 2) {
                this.map[i][COLUMNS / 2] = new Tile.Town();
            } else {
                this.map[i][COLUMNS / 2] = new Tile.River();
            }
        }

        if (mapType == MapType.Standard) {
            if (ROWS != 5 && COLUMNS != 9) {
                //TODO add some sort of error prompt
                generateRandomMap(true);
            } else {
                generateStandardMap();
            }
        } else if (mapType == MapType.Flat || mapType == MapType.Random) {
            generateRandomMap(true);
        } else if (mapType == MapType.Mountainous) {
            generateRandomMap(false);
        }
        for (int i = 0; i < 3; i++) {
            int r = (int)(Math.random() * 4);
            int c = (int) (Math.random() * 8);
            map[r][c].setCrystiteLevel(3);
            if (r - 1 >= 0 && map[r - 1][c].getCrystiteLevel() <= 2) {
                map[r - 1][c].setCrystiteLevel(2);
            }
            if (r + 1 <= 4 && map[r + 1][c].getCrystiteLevel() <= 2) {
                map[r + 1][c].setCrystiteLevel(2);
            }
            if (c - 1 >= 0 && map[r][c - 1].getCrystiteLevel() <= 2) {
                map[r][c - 1].setCrystiteLevel(2);
            }
            if (c + 1 <= 8 && map[r][c + 1].getCrystiteLevel() <= 2) {
                map[1][c + 1].setCrystiteLevel(2);
            }
            if (r - 2 >= 0 && map[r - 2][c].getCrystiteLevel() <= 1) {
                map[r - 2][c].setCrystiteLevel(1);
            }
            if (r + 2 <= 4 && map[r + 2][c].getCrystiteLevel() <= 1) {
                map[r + 2][c].setCrystiteLevel(1);
            }
            if (c - 2 >= 0 && map[r][c - 2].getCrystiteLevel() <= 1) {
                map[r][c - 2].setCrystiteLevel(1);
            }
            if (c + 2 <= 8 && map[r][c + 2].getCrystiteLevel() <= 1) {
                map[r][c + 2].setCrystiteLevel(1);
            }
            if (c + 1 <= 8 && r + 1 <= 4 && map[r + 1][c + 1].getCrystiteLevel() <= 1) {
                map[r + 1][c + 1].setCrystiteLevel(1);
            }
            if (c + 1 <= 8 && r - 1 >= 0 && map[r - 1][c + 1].getCrystiteLevel() <= 1) {
                map[r - 1][c + 1].setCrystiteLevel(1);
            }
            if (c - 1 >= 0 && r - 1 >= 0 && map[r - 1][c - 1].getCrystiteLevel() <= 1) {
                map[r - 1][c - 1].setCrystiteLevel(1);
            }
            if (c - 1 >= 0 && r + 1 <= 4 && map[r + 1][c - 1].getCrystiteLevel() <= 1) {
                map[r + 1][c - 1].setCrystiteLevel(1);
            }

        }
        stepState();
    }

    private void generateStandardMap() {

        // Allowed to hardcode since this function won't be called unless
        // ROWS == 5 and COLUMNS == 9

        map[0][0] = new Tile.Plain();
        map[0][1] = new Tile.Plain();
        map[0][2] = new Tile.Mountain1();
        map[0][3] = new Tile.Plain();
        map[0][5] = new Tile.Plain();
        map[0][6] = new Tile.Mountain3();
        map[0][7] = new Tile.Plain();
        map[0][8] = new Tile.Plain();

        map[1][0] = new Tile.Plain();
        map[1][1] = new Tile.Mountain1();
        map[1][2] = new Tile.Plain();
        map[1][3] = new Tile.Plain();
        map[1][5] = new Tile.Plain();
        map[1][6] = new Tile.Plain();
        map[1][7] = new Tile.Plain();
        map[1][8] = new Tile.Mountain3();

        map[2][0] = new Tile.Mountain3();
        map[2][1] = new Tile.Plain();
        map[2][2] = new Tile.Plain();
        map[2][3] = new Tile.Plain();
        map[2][5] = new Tile.Plain();
        map[2][6] = new Tile.Plain();
        map[2][7] = new Tile.Plain();
        map[2][8] = new Tile.Mountain1();

        map[3][0] = new Tile.Plain();
        map[3][1] = new Tile.Mountain2();
        map[3][2] = new Tile.Plain();
        map[3][3] = new Tile.Plain();
        map[3][5] = new Tile.Plain();
        map[3][6] = new Tile.Mountain2();
        map[3][7] = new Tile.Plain();
        map[3][8] = new Tile.Plain();

        map[4][0] = new Tile.Plain();
        map[4][1] = new Tile.Plain();
        map[4][2] = new Tile.Mountain2();
        map[4][3] = new Tile.Plain();
        map[4][5] = new Tile.Plain();
        map[4][6] = new Tile.Plain();
        map[4][7] = new Tile.Plain();
        map[4][8] = new Tile.Mountain2();
    }

    private final Random random = new Random();

    private void generateRandomMap(boolean isFlat) {

        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++) {
                Tile tile;
                if (j != COLUMNS / 2) {
                    int rando;
                    if (isFlat) {
                        // 1/4th of the map is supposed to be mountainous
                        rando = random.nextInt(4);
                        if (rando == 0 || rando == 1 || rando == 2) {
                            //Maps are usually flat
                            tile = new Tile.Plain();
                        } else {
                            int rando2 = random.nextInt(3);
                            if (rando2 == 0) {
                                tile = new Tile.Mountain1();
                            } else if (rando2 == 1) {
                                tile = new Tile.Mountain2();
                            } else {
                                tile = new Tile.Mountain3();
                            }
                        }
                    } else {
                        rando = random.nextInt(2);
                        if (rando == 0) {
                            tile = new Tile.Plain();
                        } else {
                            int rando2 = random.nextInt(3);
                            if (rando2 == 0) {
                                tile = new Tile.Mountain1();
                            } else if (rando2 == 1) {
                                tile = new Tile.Mountain2();
                            } else {
                                tile = new Tile.Mountain3();
                            }
                        }
                    }
                    map[i][j] = tile;
                }
            }
        }
    }

    public Tile[][] getMap() {
        return map;
    }

    public Store getStore() {
        return store;
    }

    private void setTilePrices() {
        Random gen = new Random();
        for (Tile[] columns : map) {
            for (Tile element : columns) {
                if (turn <= 2) {
                    element.setBuyPrice(0);
                } else {
                    element.setBuyPrice(element.getBaseBuyPrice() + (turn * gen.nextInt(100)));
                }
            }
        }
    }

    private void calcProduction() {
        for (Tile[] col : map) {
            for (Tile element : col) {
                if (element.getMule() != null && element.getOwner() != null) {
                    Inventory inv = element.getOwner().getInventory();
                    if (inv.getItem(Resource.Energy) > 0) {
                        inv.addItem(element.production());
                        inv.subItem(Resource.Energy, 1);
                    }
                }
            }
        }
    }

    private static final int[] ROUND_GAMBLE_BONUS = {0, 50, 50, 50, 100, 100, 100, 100, 150, 150, 150, 150, 200};

    public void gamble() {
        int base = ROUND_GAMBLE_BONUS[turn];

        int remainingTime = timer.getRemaining();

        int random = (new Random()).nextInt(2 * remainingTime);

        int gambleMoney = base + random;

        System.out.println(currentPlayer.getName() + " won $" + gambleMoney + " gambling.");

        currentPlayer.addMoney(gambleMoney);

        stepState();
    }

    private interface IGameState extends Serializable{
        IGameState stepState();

        GameState getStateAsEnum();
    }

    private class GameStateConfig implements IGameState {
        public IGameState stepState() {
            MuleGame.this.initGame();

            return new GameStateLandBuy();
        }

        public GameState getStateAsEnum() {
            return GameState.Config;
        }
    }

    private class GameStateLandBuy implements IGameState {
        final Queue<Player> players;

        public GameStateLandBuy() {
            MuleGame.this.setTilePrices();
            MuleGame.this.calcProduction();
            MuleGame.this.turn++;

            MuleGame.this.players.sort((a, b) -> a.getScore() - b.getScore());

            players = new LinkedList<>(MuleGame.this.players);

            currentPlayer = players.remove();
        }

        public IGameState stepState() {
            // Huzzah! We've gone thru everyone! Time for development!
            if (players.size() == 0) {
                return new GameStateDevelopment();
            } else {
                // Pop a player from the queue
                MuleGame.this.currentPlayer = players.remove();
            }

            return this;
        }

        public GameState getStateAsEnum() {
            return GameState.LandBuy;
        }
    }

    private static final int RANDOM_EVENT_CHANCE = 27;
    private static final int[] RANDOM_EVENT_M = {0, 25, 25, 25, 50, 50, 50, 50, 75, 75, 75, 75, 100};
    public String eventMessage;

    private void doRandomEvent() {
        boolean lowestScore = this.players.get(0).equals(currentPlayer);

        if(random.nextInt(100) < RANDOM_EVENT_CHANCE)
        {
            int m = RANDOM_EVENT_M[turn];
            RandomEvent event = randomEvents.get(random.nextInt(randomEvents.size()));

            if(event.isBad() && lowestScore) {
                eventMessage = null;
                return;
            }

            event.doEvent(currentPlayer, m);
            eventMessage = event.getMessage(m);
        } else {
            eventMessage = null;
        }
    }

    private static final int[] ROUND_REQUIRED_FOOD = {0, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5};

    private class GameStateDevelopment implements IGameState {
        final Queue<Player> players;

        private void nextTurn() {
            // Pop a player from the queue
            currentPlayer = players.remove();

            // Ensure that the timer isn't already running
            timer.cancelTimer();

            int roundTime;
            int food = currentPlayer.getInventory().getItem(Resource.Food);

            if (food < ROUND_REQUIRED_FOOD[turn]) {
                roundTime = 5 + 45 * food / ROUND_REQUIRED_FOOD[turn];
            } else {
                roundTime = 50;
            }

            doRandomEvent();

            timer.setTimer(roundTime);

            listeners.forEach((l) -> l.roundTimerChanged(true, roundTime, true));
        }

        public GameStateDevelopment() {
            players = new LinkedList<>(MuleGame.this.players);

            nextTurn();
        }

        public IGameState stepState() {
            // Huzzah! We've gone thru everyone! Time for auction!
            if (players.size() == 0) {
                if (landBuyDisabled) {
                    return new GameStateDevelopment();
                } else {
                    return new GameStateLandBuy();
                }
            } else {
                nextTurn();
            }

            return this;
        }

        public GameState getStateAsEnum() {
            return GameState.Development;
        }
    }

    // Initialize to config game state
    private IGameState state = new GameStateConfig();

    // These are to tell the outside world about the state
    // so that we don't have to expose our IGameStates
    public enum GameState {
        Config, Development, LandBuy
    }

    public void stepState() {
        timer.cancelTimer();
        listeners.forEach((l) -> l.roundTimerChanged(false, 0, false));

        state = state.stepState();

        GameState st = state.getStateAsEnum();

        listeners.forEach((l) -> l.stateUpdated(st));
    }

    public GameState getCurrentState() {
        return state.getStateAsEnum();
    }

    private boolean landBuyDisabled = false;

    public void disableLandBuy() {
        this.landBuyDisabled = true;
    }

    private transient List<MuleGameStateChangeListener> listeners = new ArrayList<>();

    public void addGameStateListener(MuleGameStateChangeListener listener) {
        if (listener == null) {
            throw new IllegalArgumentException("listener can't be null");
        }

        listeners.add(listener);
    }

    public void removeGameStateListener(MuleGameStateChangeListener listener) {
        if (listener == null) {
            return;
        }

        listeners.remove(listener);
    }

    public interface MuleGameStateChangeListener {
        void stateUpdated(GameState state);

        void roundTimerChanged(boolean isRunning, int remaining, boolean isTimerSet);
    }

    public void onTimerTick(int remaining) {
        System.out.println("Timer remaining " + remaining);
        listeners.forEach((l) -> l.roundTimerChanged(true, remaining, false));
    }

    public void onTimerExpiry() {
        System.out.println("Round timer expired");
        listeners.forEach((l) -> l.roundTimerChanged(false, 0, false));
        stepState();
    }

    public void saveToFile(String path) {
        try {
            FileOutputStream fo = new FileOutputStream(path);
            ObjectOutputStream os = new ObjectOutputStream(fo);
            os.writeObject(this);
            os.close();
            fo.close();
        } catch (IOException exc) {
            exc.printStackTrace();
        }
    }

    public static MuleGame createFromFile(String path) {
        try {
            FileInputStream fi = new FileInputStream(path);
            ObjectInputStream oi = new ObjectInputStream(fi);
            MuleGame g = (MuleGame)oi.readObject();

            g.listeners = new ArrayList<>();

            // Reset the timer so that it continues (threads can't be serialized)
            if(g.timer.getRemaining() > 0) {
                g.timer.setTimer(g.timer.getRemaining());
            }

            g.timer.fixAfterDeserialize();

            return g;
        } catch (Exception exc) {
            return null;
        }
    }
}
