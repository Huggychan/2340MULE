package game;

import java.io.Serializable;

/**
 * Created by yash on 9/21/15.
 */
public abstract class Mule implements Serializable {

    public abstract Resource getResource();

    public abstract int getOutfitPrice();

    public static class NonOutfittedMule extends Mule {

        @Override
        public Resource getResource() {
            return null;
        }

        @Override
        public int getOutfitPrice() {
            return 0;
        }

    }

    public static class FoodMule extends Mule {

        @Override
        public Resource getResource() {
            return Resource.Food;
        }

        @Override
        public int getOutfitPrice() {
            return 25;
        }

    }

    public static class EnergyMule extends Mule {

        @Override
        public Resource getResource() {
            return Resource.Energy;
        }

        @Override
        public int getOutfitPrice() {
            return 50;
        }

    }

    public static class OreMule extends Mule {

        @Override
        public Resource getResource() {
            return Resource.Ore;
        }

        @Override
        public int getOutfitPrice() {
            return 75;
        }

    }

    public static class CrystiteMule extends Mule {

        @Override
        public Resource getResource() {
            return Resource.Crystite;
        }

        @Override
        public int getOutfitPrice() {
            return 100;
        }

    }

}