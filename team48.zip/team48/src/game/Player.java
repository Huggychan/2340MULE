package game;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Created by Matthew on 9/11/2015.
 */
public class Player implements Serializable {

    public enum Race {

        Human(600), Bonzoid(1000), Buzzite(1000), Flapper(1600), Ugaite(1000);

        private final int startingMoney;

        Race(int startingMoney) {
            this.startingMoney = startingMoney;
        }

        public int getStartingMoney() {
            return startingMoney;
        }

    }

    public enum Color { Red, Blue, Green, Yellow }

    private final String name;
    private final Race race;
    private final Color color;

    private int money;
    private final Inventory inventory;
    private final List<Tile> ownedTiles;


    public Player(String name, Race race, Color color) {
        this.name = name;
        this.race = race;
        this.color = color;

        money = race.getStartingMoney();
        inventory = new Inventory();
        ownedTiles = new ArrayList<>();
    }


    public String getName() {
        return name;
    }

    public Race getRace() {
        return race;
    }

    public Color getColor() {
        return color;
    }

    public int getMoney() {
        return money;
    }

    public void addMoney(int amt) {
        money = Math.max(money + amt, 0);
    }

    public void subMoney(int amt) {
        addMoney(-amt);
    }

    public Inventory getInventory() {
        return inventory;
    }

    public boolean purchaseTile(Tile tile) {
        if(!tile.forSale() || money - tile.getBuyPrice() < 0) {
            return false;
        }

        subMoney(tile.getBuyPrice());
        tile.purchased(this);
        ownedTiles.add(tile);

        return true;
    }

    public boolean sellTile(Tile tile) {
        if(!ownedTiles.contains(tile)) {
            return false;
        }

        money += tile.getSellPrice();
        tile.sold();
        ownedTiles.remove(tile);

        return true;
    }

    public static boolean validateName(String name) {
        if (name == null) {
            return false;
        }

        return !(name.length() <= 0 || name.length() > 10);

    }

    public int getScore() {
        return money + (ownedTiles.size() * 500) +
                Stream.of(inventory.getItems()).mapToInt(i -> i.getResource().getBasePrice() * i.getAmount()).sum();
    }

    @Override
    public String toString() {
        return name + ' ' + race + ' ' + color + " Score: " + getScore();
    }
}
