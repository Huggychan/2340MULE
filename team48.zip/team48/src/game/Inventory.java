package game;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by southgatew on 10/14/15.
 */
public class Inventory implements Serializable {

    private final Map<Resource, Integer> items;

    public Inventory() {
        items = new HashMap<>();
    }

    public Item[] getItems() {
        return items.entrySet().stream().map(e -> new Item(e.getKey(), e.getValue())).toArray(Item[]::new);
    }

    public int getItem(Resource resource) {
        return items.getOrDefault(resource, 0);
    }

    public void addItem(Item item) {
        addItem(item.getResource(), item.getAmount());
    }

    public void addItem(Resource resource, int amount) {
        int newAmount = Math.max(0, amount + items.getOrDefault(resource, 0));
        items.put(resource, newAmount);
    }

    public void subItem(Item item) {
        addItem(item.getResource(), -item.getAmount());
    }

    public void subItem(Resource resource, int amount) {
        addItem(resource, -amount);
    }


}
