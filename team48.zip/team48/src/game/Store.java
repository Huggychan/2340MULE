package game;

import java.io.Serializable;

/**
 * Created by matth on 10/14/2015.
 */
public class Store implements Serializable {

    private final Inventory inventory;

    public Store() {
        inventory = new Inventory();
    }

    public Inventory getInventory() {
        return inventory;
    }

    public boolean purchaseResource(Resource resource, Player player) {
        if(player.getMoney() - resource.getBasePrice() < 0) {
            return false;
        }
        if(inventory.getItem(resource) <= 0) {
            return false;
        }

        inventory.subItem(resource, 1);
        player.getInventory().addItem(resource, 1);
        player.subMoney(resource.getBasePrice());
        return true;
    }

    public boolean sellResource(Resource resource, Player player) {
        if(player.getInventory().getItem(resource) <= 0) {
            return false;
        }

        inventory.addItem(resource, 1);
        player.getInventory().subItem(resource, 1);
        player.addMoney(resource.getBasePrice());
        return true;
    }

    public boolean purchaseOutfitMule(Mule mule, Player player) {
        if(player.getMoney() - mule.getOutfitPrice() < 0) {
            return false;
        }

        player.subMoney(mule.getOutfitPrice());
        return true;
    }

}