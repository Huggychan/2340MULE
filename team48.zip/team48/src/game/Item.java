package game;

import java.io.Serializable;

/**
 * Created by southgatew on 10/14/15.
 */
public class Item implements Serializable {

    private final Resource resource;
    private final int amount;

    public Item(Resource resource, int amount) {
        this.resource = resource;
        this.amount = amount;
    }

    public Resource getResource() {
        return resource;
    }

    public int getAmount() {
        return amount;
    }

}
