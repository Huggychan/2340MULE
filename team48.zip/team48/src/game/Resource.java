package game;

/**
 * Created by southgatew on 10/14/15.
 */
public enum  Resource {

    Food(30), Ore(25), Energy(50), Crystite(100), Mule(100);

    private final int basePrice;

    Resource(int basePrice) {
        this.basePrice = basePrice;
    }

    public int getBasePrice() {
        return basePrice;
    }

}
