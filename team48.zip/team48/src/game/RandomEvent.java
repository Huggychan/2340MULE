package game;

import java.io.Serializable;

/**
 * Created by southgatew on 10/22/15.
 */
public abstract class RandomEvent implements Serializable {

    public abstract String getMessage(int m);

    public abstract void doEvent(Player player, int m);

    public abstract boolean isBad();

    public static class RandomEvent1 extends RandomEvent {

        @Override
        public String getMessage(int m) {
            return "YOU JUST RECEIVED A PACKAGE FROM THE GT ALUMNI CONTAINING 3 FOOD AND 2 ENERGY UNITS.";
        }

        @Override
        public void doEvent(Player player, int m) {
            player.getInventory().addItem(Resource.Food, 3);
            player.getInventory().addItem(Resource.Energy, 2);
        }

        @Override
        public boolean isBad() {
            return false;
        }

    }

    public static class RandomEvent2 extends RandomEvent {

        @Override
        public String getMessage(int m) {
            return "A WANDERING TECH STUDENT REPAID YOUR HOSPITALITY BY LEAVING TWO BARS OF ORE.";
        }

        @Override
        public void doEvent(Player player, int m) {
            player.getInventory().addItem(Resource.Ore, 2);
        }

        @Override
        public boolean isBad() {
            return false;
        }

    }

    public static class RandomEvent3 extends RandomEvent {

        @Override
        public String getMessage(int m) {
            return String.format("THE MUSEUM BOUGHT YOUR ANTIQUE PERSONAL COMPUTER FOR $%d.", (8 * m));
        }

        @Override
        public void doEvent(Player player, int m) {
            player.addMoney(8 * m);
        }

        @Override
        public boolean isBad() {
            return false;
        }

    }

    public static class RandomEvent4 extends RandomEvent {

        @Override
        public String getMessage(int m) {
            return String.format("YOU FOUND A DEAD MOOSE RAT AND SOLD THE HIDE FOR $%d.", (2 * m));
        }

        @Override
        public void doEvent(Player player, int m) {
            player.addMoney(2 * m);
        }

        @Override
        public boolean isBad() {
            return false;
        }

    }

    public static class RandomEvent5 extends RandomEvent {

        @Override
        public String getMessage(int m) {
            return String.format("FLYING CAT-BUGS ATE THE ROOF OFF YOUR HOUSE. REPAIRS COST $%d", (4 * m));
        }

        @Override
        public void doEvent(Player player, int m) {
            player.subMoney(4 * m);
        }

        @Override
        public boolean isBad() {
            return true;
        }

    }

    public static class RandomEvent6 extends RandomEvent {

        @Override
        public String getMessage(int m) {
            return "MISCHIEVOUS UGA STUDENTS BROKE INTO YOUR STORAGE SHED AND STOLE HALF YOUR FOOD.";
        }

        @Override
        public void doEvent(Player player, int m) {
            Inventory inv = player.getInventory();
            inv.subItem(Resource.Food, inv.getItem(Resource.Food) / 2);
        }

        @Override
        public boolean isBad() {
            return true;
        }

    }

    public static class RandomEvent7 extends RandomEvent {

        @Override
        public String getMessage(int m) {
            return String.format("YOUR SPACE GYPSY INLAWS MADE A MESS OF THE TOWN. IT COST YOU $%d TO CLEAN IT UP.", (6 * m));
        }

        @Override
        public void doEvent(Player player, int m) {
            player.subMoney(6 * m);
        }

        @Override
        public boolean isBad() {
            return true;
        }

    }

}
