package game;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ian on 9/17/15.
 */
public abstract class Tile implements Serializable {

    private final Map<Resource, Integer> productions;
    private int buyPrice;
    private int sellPrice;
    private Player owner;
    private Mule mule;

    private int crystiteLevel;

    public Tile() {
        productions = new HashMap<>();
    }

    protected void addProduction(Resource resource, int amount) {
        productions.put(resource, amount);
    }

    public int getBuyPrice() {
        return buyPrice;
    }

    public int getSellPrice() {
        return sellPrice;
    }

    public void setBuyPrice(int buyPrice) {
        this.buyPrice = buyPrice;
    }

    public void setSellPrice(int sellPrice) {
        this.sellPrice = sellPrice;
    }

    public Player getOwner() {
        return owner;
    }

    public Mule getMule() {
        return mule;
    }

    public void purchased(Player owner) {
        this.owner = owner;
    }

    public int getCrystiteLevel() {
        return crystiteLevel;
    }

    public void setCrystiteLevel(int crystiteLevel) {
        this.crystiteLevel = crystiteLevel;
    }

    public void sold() {
        owner = null;
        mule = null;
    }

    public void placeMule(Mule mule) {
        if(owner != null) {
            this.mule = mule;
        }
    }

    public Mule removeMule() {
        Mule temp = mule;
        mule = null;
        return temp;
    }

    public Item production() {
        return mule == null ? null :
                new Item(mule.getResource(), productions.getOrDefault(mule.getResource(), 0));
    }

    public boolean forSale() {
        return canBuy() && owner == null;
    }

    public abstract boolean canBuy();

    public abstract int getBaseBuyPrice();

    public abstract int getBaseSellPrice();

    public static class River extends Tile {

        public River() {
            addProduction(Resource.Food, 4);
            addProduction(Resource.Energy, 2);
            addProduction(Resource.Ore, 0);
        }

        @Override
        public String toString() {
            return "River";
        }

        @Override
        public boolean canBuy() {
            return true;
        }

        @Override
        public int getBaseBuyPrice() {
            return 300;
        }

        @Override
        public int getBaseSellPrice() {
            return 400;
        }

    }

    public static class Plain extends Tile {

        public Plain() {
            addProduction(Resource.Food, 2);
            addProduction(Resource.Energy, 3);
            addProduction(Resource.Ore, 1);
        }

        @Override
        public String toString() {
            return "Plain";
        }


        @Override
        public boolean canBuy() {
            return true;
        }

        @Override
        public int getBaseBuyPrice() {
            return 300;
        }

        @Override
        public int getBaseSellPrice() {
            return 400;
        }

    }

    public static class Mountain1 extends Tile {

        public Mountain1() {
            addProduction(Resource.Food, 1);
            addProduction(Resource.Energy, 1);
            addProduction(Resource.Ore, 2);
        }

        @Override
        public String toString() {
            return "Mountain1";
        }


        @Override
        public boolean canBuy() {
            return true;
        }

        @Override
        public int getBaseBuyPrice() {
            return 300;
        }

        @Override
        public int getBaseSellPrice() {
            return 400;
        }

    }

    public static class Mountain2 extends Tile {

        public Mountain2() {
            addProduction(Resource.Food, 1);
            addProduction(Resource.Energy, 1);
            addProduction(Resource.Ore, 3);
        }

        @Override
        public String toString() {
            return "Mountain2";
        }


        @Override
        public boolean canBuy() {
            return true;
        }

        @Override
        public int getBaseBuyPrice() {
            return 300;
        }

        @Override
        public int getBaseSellPrice() {
            return 400;
        }

    }

    public static class Mountain3 extends Tile {

        public Mountain3() {
            addProduction(Resource.Food, 1);
            addProduction(Resource.Energy, 1);
            addProduction(Resource.Ore, 4);
        }

        @Override
        public String toString() {
            return "Mountain3";
        }

        @Override
        public boolean canBuy() {
            return true;
        }

        @Override
        public int getBaseBuyPrice() {
            return 300;
        }

        @Override
        public int getBaseSellPrice() {
            return 400;
        }

    }

    public static class Town extends Tile {

        @Override
        public boolean canBuy() {
            return false;
        }

        @Override
        public int getBaseBuyPrice() {
            return 0;
        }

        @Override
        public int getBaseSellPrice() {
            return 0;
        }

    }

}
