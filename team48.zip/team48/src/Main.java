import game.MuleGame;
import game.Player;
import javafx.application.Application;
import javafx.stage.Stage;
import ui.config.NumberOfPlayersUI;
import ui.game.GameUI;

import java.io.File;

public class Main extends Application {

    private static final boolean TEST = true;

    @Override
    public void start(Stage primaryStage) throws Exception {
        if (new File("mulegame.txt").exists()) {
            MuleGame game = MuleGame.createFromFile("mulegame.txt");

            if (game != null) {
                GameUI ui = new GameUI();

                ui.open(game);
                ui.forceUIUpdate();

                // Wire up the listener to the new UI
                game.addGameStateListener(ui);

                return;
            }
        }

        MuleGame game = new MuleGame();

        if (false) {
            game.addPlayer(new Player("test1", Player.Race.Bonzoid, Player.Color.Blue));
            game.addPlayer(new Player("test2", Player.Race.Buzzite, Player.Color.Red));
            game.setDifficulty(MuleGame.Difficulty.Beginner);
            game.generateMap(MuleGame.MapType.Standard);
            new GameUI().open(game);
        } else {
            new NumberOfPlayersUI().open(game);
        }

    }


    public static void main(String[] args) {
        launch(args);
    }
}
